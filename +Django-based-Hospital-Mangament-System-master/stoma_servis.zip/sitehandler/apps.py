from django.apps import AppConfig


class SitehandlerConfig(AppConfig):
    name = 'sitehandler'
